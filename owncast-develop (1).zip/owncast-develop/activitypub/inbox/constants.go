package inbox

import "time"

const (
	maxAgeForEngagement = time.Hour * 36
)
