//go:build enable_updates
// +build enable_updates

package config

func init() {
	EnableAutoUpdate = true
}
