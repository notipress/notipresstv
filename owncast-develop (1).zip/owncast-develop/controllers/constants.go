package controllers

// POST is the HTTP POST method.
const POST = "POST"

// GET is the HTTP GET method.
const GET = "GET"
