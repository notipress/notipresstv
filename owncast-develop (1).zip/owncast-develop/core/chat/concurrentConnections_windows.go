//go:build windows
// +build windows

package chat

func setSystemConcurrentConnectionLimit(limit int64) {}
