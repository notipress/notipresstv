package notifications

const (
	// BrowserPushNotification represents a push notification for a browser.
	BrowserPushNotification = "BROWSER_PUSH_NOTIFICATION"
)
